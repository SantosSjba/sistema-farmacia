<?php
include("../seguridad.php");
include_once("../central/centralproducto.php");
include_once("../conexion/clsConexion.php");
?>
<div class="page-container">
  <div class="main-content">
  	<?php include('../central/cabecera.php');?>
		<blockquote class="blockquote-default" align="center">
			<p><strong><h3>DERECHOS DE AUTOR:<h3></strong></p>

    <p align="left"><b>SISTEMA:</b></p>
    <p align="left">Sistema de Farmacia multisucursal(SISFARMA)</p>

    <p align="left"><b>VERSION:</b></p>
    <p align="left">SISFARMA CON FACTURA ELECTRONICA  UBL 2.1</p>

    <p align="left"><b>EMPRESA:</b></p>
    <p align="left">infantC</p>

    <p align="left"><b>DESARROLLADO POR:</b></p>
    <p align="left"><a href="#"  target="_blank">Infar</a></p>
		</blockquote>
</div>
</div>
<?php include("../central/pieproducto.php");?>
